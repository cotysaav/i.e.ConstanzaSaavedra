# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

print("calculadora de fecha dd-mm-yyyy")

print("indique dia  (dd)")
dd = int(input())
print ("dia: ",dd)

print ("indique mes (mm)")
mm = int(input())
print("mes: ",mm)

print("indique año (yyyy)")
yyyy = int(input())
print("año: ",yyyy)      

#se asegura de que la fecha "pueda" existir 

while dd < 1 or dd > 31:
    print("indique un dia valido (dd)")
    dd = int(input())
    
while mm < 1 or mm > 12:
    print("indique un mes valido (mm)")
    mm = int(input())
    
while yyyy < 1 or yyyy > 9999:
    print("indique año (yyyy)")
    yyyy = int(input())
    
#cualcula si en la fecha indicada el año es bisiesto  
  
bisiesto = 0 #indica que no es bisisesto    
if yyyy%4 == 0 and yyyy%100 == 0 and yyyy%400 == 0: 
    bisiesto=1 
if yyyy%4 == 0 and yyyy%100 != 0 and yyyy%400 != 0: 
    bisiesto=1  #si se cumple la condicion el año es bisiesto 
    
#sumar dias de los meses

meses = [31,28,31,30,31,30,31,31,30,31,30,31] 

sumas = 0 
ciclos = mm - 2
while 0 <= ciclos :
    sumas = sumas + meses[ciclos]
    ciclos = ciclos - 1
    
# suma de los dias hasta la fecha indicada 

resultado1 = sumas + dd + bisiesto
if (sumas + dd) <= 4: 
    resultado3 = 4 - sumas + dd 
    
if (sumas + dd) > 4:
    resultado3 = 365 + 4 - resultado1    
    if mm >= 3: 
        resultado3 = resultado3 + bisiesto 
        
#resultados

print("la cantidad de dias desde el inicio del año a la fecha indicada son: ", resultado1)
if bisiesto == 0: 
    print("el año no es bisiesto")
    
if bisiesto == 1: 
    print("el año es bisiesto")
    
print("faltan  ", resultado3, "dias para el natalicio de Isaac Newton")
 
   
    
    
    
        
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
