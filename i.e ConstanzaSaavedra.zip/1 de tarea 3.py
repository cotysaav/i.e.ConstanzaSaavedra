# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
print("escoge un numero que repesenta al valor a ")
a = int(input())
print("escoge un numero que represente al valor b ")
b = int(input())

if b == 0: #b en una division no puede ser 0 

    print("b no puede ser 0") 
    print("intentalo nuevamente(ingrese un nuevo valor de b )")
    b = int(input())
div = a%b #calcula el resto de la division
res = a/b

if div != 0:
    print("el resultados no es entero")
   
else:
    print("el resultado es entero")
   
print("El resultado de a/b es ", res)


