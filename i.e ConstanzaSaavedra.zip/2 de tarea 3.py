#!/usr/bin/env python3
# -*- coding: utf-8 -*-


print("calculadora de promedio de notas")


print("ingrese cantidad de notas que desea promediar:")
c= int(input()) #cantidad de notas a promediar
if c < 1 : 
    print("su cantidad de notas no puede ser menor que 1")
    print("ingreselo nuevamente")
    c = int(input()) #ingrese nueva cantidad para promediar
    

ciclo=1
sumas=0

while ciclo <= c:
    print("señale su nota numero ", ciclo)
    sumas = sumas + float(input()) #es la suma de variables en el ciclo
    ciclo = ciclo + 1 #suma una nota al conteo
   
promedio= sumas/c    
   
print ("el resultado de tu promedio es : ",promedio )

#resultado del promedio + mensaje dependiendo si aprobo o no:
if promedio >= 4.0:
    print("felicitaciones,vas camino a aprobar.")
   
elif promedio >= 3.0:
    print("Atencion, vas camino a reprobar.")
     
elif promedio < 3.0:
    print("Pocas posibilidades de aprobar")